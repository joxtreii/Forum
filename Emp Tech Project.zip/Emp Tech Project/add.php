 <?php  
 
  if(isset($_POST['share'])){
  $codename = $_POST['codename'];
  $message = $_POST['message'];
    
  date_default_timezone_set("Asia/Manila");
  $date = date("h:ia | l m/d/y");
    
    if($codename !="" || $message !=""){

       $q="INSERT INTO s".$codename." (codename,message,dates)
            VALUES ('".$codename."','".$message."','".$date."')
           ";
                        
             if(mysqli_query($connect, $q)){
                echo "<div class='well'>
                <h4> ".$codename." </h4>
                <p>".$message."</p>
                <p>".$date."</p>

                </div>";
            } else {
              echo "not connected";
            }
    }else {
      echo "can't insert";
    }
  }else {
    echo "error";
  }

  $get = "SELECT * FROM s".$codename." ORDER BY ID DESC";
                    $show = mysqli_query($connect, $get); 
                    while($row = mysqli_fetch_assoc($show)){
                      $id = $row['ID'];
                      $codename = $row['codename'];
                      $message = $row['message'];
                      $date = $row['dates'];

                      echo "<div class='well'>
                             <h4> ".$codename." </h4><hr>
                             <p>".$message."</p>
                             <p>".$date."</p>
                          </div>";
                    }

?>