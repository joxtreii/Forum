<!DOCTYPE html>
<html>
<head>
	<title>
		
	</title>
</head>
<body>
	<script>
		var ime = setInterval(doo, 10000);
		function doo(){
			window.location.assign("index.php");
		}
	</script>
</body>
</html>
