<?php
  include("connectserver.php");

  $dates = date("h:ia l Y/m/d");

  if(isset($_POST['shares'])){
      $codenames = $_POST['codenames'];
      $messages = $_POST['messages'];
      $dates = date("h:ia l Y/m/d");

      $qu = "INSERT INTO d".$dates." (codename,message,dates)
                              VALUES ('".$codenames."','".$messages."','".$dates."')";

      if(mysqli_query($connectcom, $qu)){
          echo '<div class="well">
                          <h4>'.$codenames.'</h4>
                          <p>'.$messages.'</p>
                          <p class="grey">'.$dates.'</p>
                </div>';
      }
  }

    $do = "SELECT * FROM bully";
    $group = mysqli_query($connect,$do);
    while($ww = mysqli_fetch_assoc($group)){

          $message = $ww['message'];
          
                $get = "SELECT * FROM d".$message;
                    $merges = mysqli_query($connectcom,$get);
                    while($row = mysqli_fetch_assoc($merges)){
                      $codenames = $row['codenames'];
                      $messages = $row['messages'];
                      $dates = $row['dates'];

                      echo '<div class="well">
                          <h4>'.$codenames.'</h4>
                          <p>'.$messages.'</p>
                          <p class="grey">'.$dates.'</p>
                      </div>';
                    }
    } 
?>
